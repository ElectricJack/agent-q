from pathlib import Path
import copy,hashlib,importlib.util,json,os,shutil,subprocess,tempfile,types,datetime
ROOT=Path('/home/jkern/dev/agent-q')
OUT=Path(__file__).parent
results=[]
def check(name, transform=None, override=False, expected=1):
 with tempfile.TemporaryDirectory(prefix='aq-candidate-negative-') as directory:
  base=Path(directory);(base/'scripts').mkdir()
  shutil.copy2(ROOT/'scripts/check-worker-candidate.py',base/'scripts/check-worker-candidate.py')
  shutil.copytree(ROOT/'vendor',base/'vendor')
  if transform: transform(base)
  env=os.environ.copy()
  if override:env['AQ_WORKER_BIN']='/bin/false'
  command=['python3',str(base/'scripts/check-worker-candidate.py'),'--official']
  p=subprocess.run(command,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (OUT/(name+'.log')).write_text(p.stdout)
  assert p.returncode==expected,(name,p.returncode,p.stdout)
  results.append({'name':name,'command':command,'exit_code':p.returncode,'expected_exit_code':expected,'passed':True})
def revision(base):
 p=base/'vendor/worker-candidate.json';v=json.loads(p.read_text());v['source_revision']='main';p.write_text(json.dumps(v))
def archive(base):
 p=base/'vendor/aq-worker-source.tar.gz';p.write_bytes(p.read_bytes()+b'changed')
def public_drift(base,path):
 p=base/'vendor/aq-worker-protocol-0.1.1'/path;p.write_bytes(p.read_bytes()+b'\n')
 manifest=base/'vendor/worker-contracts.json';v=json.loads(manifest.read_text())
 for package in v['packages']:
  if package['name']=='aq-worker-protocol':
   for f in package['files']:
    if f['path']==path:f['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 manifest.write_text(json.dumps(v))
check('official-valid',expected=0)
check('official-rejects-local-executable',override=True)
check('rejects-floating-revision',revision)
check('rejects-corrupt-archive',archive)
check('rejects-conformance-fixture-drift',lambda p:public_drift(p,'fixtures/conformance-v2.json'))
check('rejects-test-peer-source-drift',lambda p:public_drift(p,'src/testing.rs'))
check('rejects-original-manifest-drift',lambda p:public_drift(p,'Cargo.toml.orig'))
spec=importlib.util.spec_from_file_location('product_smoke',ROOT/'scripts/product-smoke.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fixture=module.Fixture(False);fixture.dc=['mock-docker','compose'];fixture.runtime=fixture.project+'-mock';fixture.images=['mock-image'];fixture.record.update(outcome='failed',error='original injected smoke failure')
calls=[]
def fake_run(self,command,*,name,**kwargs):
 calls.append(name)
 if name=='stack-logs':raise subprocess.TimeoutExpired(command,1)
 if name=='teardown':raise OSError('injected compose teardown failure')
 return ''
fixture.run=types.MethodType(fake_run,fixture)
assert fixture.cleanup()
value=json.loads((fixture.logs/'evidence.json').read_text())
assert value['error']=='original injected smoke failure'
assert len(value['cleanup']['errors'])==2
for name in ['runtime-teardown','verified-containers','verified-volumes','verified-networks','image-teardown']:assert name in calls
assert not fixture.temp.exists()
shutil.copy2(fixture.logs/'evidence.json',OUT/'cleanup-fault-evidence.json');shutil.rmtree(fixture.logs)
results.append({'name':'cleanup-continues-after-timeout-and-oserror','passed':True,'calls':calls})
(OUT/'results.json').write_text(json.dumps({'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'scripts/check-worker-candidate.py',ROOT/'scripts/product-smoke.py']}},indent=2)+'\n')
print(json.dumps(results,indent=2))
