import os,subprocess,pathlib,json,datetime,shutil,time
root=pathlib.Path(__file__).parent
while not (root/"checks-done").exists(): time.sleep(2)
src=root/"source";docs=pathlib.Path("/home/jkern/dev/agent-q/docs/implementation")
for crate,checker in [("aq-worker","connector"),("aq-updater","update")]:
 shutil.copy2(docs/("BASE-01."+checker+"-fixture-test.rs"),src/"crates"/crate/"tests"/"base01_fixtures.rs")
env=os.environ.copy();env["BASE01_FIXTURE"]=str(docs/"BASE-01.fixtures.json");env["CARGO_BUILD_JOBS"]="4";env.pop("AQ_SOURCE_REVISION",None)
cmd=["cargo","test","--locked","-p","aq-worker","-p","aq-updater","--test","base01_fixtures"]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/"logs"/"fixtures.log").open("w") as f: p=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
(root/"fixtures-result.json").write_text(json.dumps(dict(command=cmd,started_at=start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=p.returncode),indent=2)+"\n")
print("fixtures",p.returncode,flush=True)
for crate in ["aq-worker","aq-updater"]: (src/"crates"/crate/"tests"/"base01_fixtures.rs").unlink()
