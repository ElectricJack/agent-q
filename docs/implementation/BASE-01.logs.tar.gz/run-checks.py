import os,subprocess,json,datetime,pathlib
root=pathlib.Path(__file__).parent
env=os.environ.copy();env.pop("AQ_SOURCE_REVISION",None);env["CARGO_BUILD_JOBS"]="4"
env["DATABASE_URL"]="postgres://postgres:base01-disposable@127.0.0.1:"+(root/"db-port").read_text()+"/postgres"
commands=[("fmt",["cargo","fmt","--all","--check"]),("workspace-tests",["cargo","test","--workspace","--locked"]),("updater-tests",["cargo","test","-p","aq-updater","--locked","--features","test-verifier"]),("clippy",["cargo","clippy","--workspace","--all-targets","--locked","--","-D","warnings"]),("clippy-updater",["cargo","clippy","-p","aq-updater","--all-targets","--locked","--features","test-verifier","--","-D","warnings"]),("musl-build",["cargo","build","--release","--locked","-p","aq-updater","--target","x86_64-unknown-linux-musl"])]
results=[]
for name,cmd in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print("START",name,flush=True)
 with (root/"logs"/(name+".log")).open("w") as f: p=subprocess.run(cmd,cwd=root/"source",env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,started_at=start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=p.returncode));(root/"checks.json").write_text(json.dumps(results,indent=2)+"\n");print("END",name,p.returncode,flush=True)
