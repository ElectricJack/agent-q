from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,threading,urllib.request,urllib.error,time,hashlib
ROOT=Path(__file__).parent
(ROOT/'rules.json').write_text('{}')
commits={}
class Backend(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  operation=body['operation_id'];commits.setdefault(operation,len(commits)+1)
  data=json.dumps({'operation_id':operation,'receipt':commits[operation],'grant':{'grant_sequence':1,'valid_for_ms':1000,'offer_id':'synthetic-fixture'}}).encode()
  self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
backend=ThreadingHTTPServer(('127.0.0.1',0),Backend);threading.Thread(target=backend.serve_forever,daemon=True).start()
process=subprocess.Popen(['python3','/home/jkern/dev/agent-q/scripts/recovery-smoke-proxy.py','--control',str(ROOT),'--upstream','http://127.0.0.1:'+str(backend.server_port),'--port','0'],stdout=(ROOT/'proxy.log').open('w'),stderr=subprocess.STDOUT)
def wait(call):
 deadline=time.monotonic()+10
 while time.monotonic()<deadline:
  value=call()
  if value:return value
  time.sleep(.01)
 raise RuntimeError('barrier timeout')
def events():
 p=ROOT/'events.jsonl'
 return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
def rules(mode,token,once=False):
 p=ROOT/'new.json';p.write_text(json.dumps({'/accept':{'mode':mode,'token':token,'once':once}}));p.replace(ROOT/'rules.json')
try:
 port=wait(lambda:next((v['port'] for v in events() if v['event']=='proxy_ready'),None))
 def post(operation):
  request=urllib.request.Request('http://127.0.0.1:'+str(port)+'/accept',json.dumps({'operation_id':operation}).encode(),{'Authorization':'Bearer synthetic-private-value','Content-Type':'application/json'})
  with urllib.request.urlopen(request,timeout=10) as r:return json.load(r)
 rules('drop_after_commit','drop',True)
 try:post('first');raise AssertionError('connection not dropped')
 except (OSError, __import__('http.client').client.HTTPException):pass
 assert commits['first']==1
 assert post('first')['receipt']==1
 pool=ThreadPoolExecutor(max_workers=1)
 rules('hold_before_forward','before');future=pool.submit(post,'second')
 wait(lambda:(ROOT/'before.ready').exists());assert 'second' not in commits
 (ROOT/'before.release').touch();assert future.result()['receipt']==2
 rules('hold_after_commit','after');future=pool.submit(post,'third')
 wait(lambda:(ROOT/'after.ready').exists());assert commits['third']==3 and not future.done()
 (ROOT/'after.release').touch();assert future.result()['receipt']==3
 rules('partition','partition')
 try:post('fourth');raise AssertionError('partition did not reject')
 except urllib.error.HTTPError as e:assert e.code==503
 assert 'fourth' not in commits
 assert 'synthetic-private-value' not in (ROOT/'events.jsonl').read_text()
 pool.shutdown();(ROOT/'result.json').write_text(json.dumps({'passed':True,'checks':['after-commit-close-and-replay','before-forward-barrier','after-commit-barrier','partition-before-forward','no-credential-logging'],'proxy_sha256':hashlib.sha256(Path('/home/jkern/dev/agent-q/scripts/recovery-smoke-proxy.py').read_bytes()).hexdigest()},indent=2)+'\n')
 print('proxy network tests passed',ROOT)
finally:
 process.terminate();process.wait(timeout=5);backend.shutdown()
