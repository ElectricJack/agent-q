use aq_git_core::RepositoryService;
use aq_git_protocol::Request;
use serde_json::json;
use std::time::{Duration, Instant};
fn registration() -> Request {
    Request {
        protocol_version: 1,
        request_id: "service-test".into(),
        operation: "repo.register".into(),
        repository_id: Some(uuid::Uuid::new_v4().to_string()),
        operation_id: Some(uuid::Uuid::new_v4().to_string()),
        expected_binding_generation: Some(0),
        params: json!({"identity":"test","mode":"central","remote_url":"https://user:secret@example.invalid/repository.git"}),
        deadline_ms: None,
    }
}
#[test]
fn rejects_embedded_credentials_without_journaling_them() {
    let temp = tempfile::tempdir().unwrap();
    let service = RepositoryService::open(temp.path().join("state")).unwrap();
    let request = registration();
    let operation = request.operation_id.clone().unwrap();
    let answer = service.execute(request);
    assert!(!answer.ok);
    assert!(service.root.operation(&operation).unwrap().is_none());
    assert_eq!(service.repositories.runner.metrics().spawns, 0);
}
#[test]
fn expired_admission_creates_no_mutation_intent() {
    let temp = tempfile::tempdir().unwrap();
    let service = RepositoryService::open(temp.path().join("state")).unwrap();
    let mut request = registration();
    request.params = json!({"identity":"test","mode":"worker"});
    request.deadline_ms = Some(1);
    let operation = request.operation_id.clone().unwrap();
    let answer = service.execute_admitted(request, Instant::now() - Duration::from_millis(100));
    assert_eq!(answer.error.unwrap().code, "deadline_exceeded");
    assert!(service.root.operation(&operation).unwrap().is_none());
    assert_eq!(service.repositories.runner.metrics().spawns, 0);
}

#[test]
fn existing_bindings_require_matching_executable_behavior_before_admission() {
    use std::os::unix::fs::PermissionsExt;
    let temp = tempfile::tempdir().unwrap();
    let path = temp.path().join("state");
    let service = RepositoryService::open(&path).unwrap();
    let mut register = registration();
    register.params = json!({"identity":"test","mode":"worker"});
    assert!(service.execute(register).ok);
    let root = (*service.root).clone();
    drop(service);
    let executable = temp.path().join("old-git");
    std::fs::write(&executable, "#!/bin/sh\nprintf 'git version 2.42.0\\n'\n").unwrap();
    std::fs::set_permissions(&executable, std::fs::Permissions::from_mode(0o700)).unwrap();
    let error = match RepositoryService::from_state_root_with_git(root, executable) {
        Ok(_) => panic!("unverified replacement executable was admitted"),
        Err(error) => error,
    };
    assert_eq!(error.code, "unsupported_feature");
    let diagnostic = RepositoryService::for_diagnostics(
        aq_git_core::state::StateRoot::open_for_recovery(path).unwrap(),
    )
    .unwrap();
    let request = Request {
        protocol_version: 1,
        request_id: "doctor".into(),
        operation: "doctor".into(),
        repository_id: None,
        operation_id: None,
        expected_binding_generation: None,
        params: json!({}),
        deadline_ms: None,
    };
    assert!(diagnostic.execute(request).ok);
}
