use super::*;
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Update {
    binding: Binding,
    reason: String,
}
impl RepositoryManager {
    pub fn repository_lifecycle(&self, id: &str) -> Arc<RwLock<()>> {
        self.gates
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .entry(id.into())
            .or_insert_with(|| Arc::new(RwLock::new(())))
            .clone()
    }
    pub(super) fn update_binding(&self, r: &Request) -> Result<Value> {
        let id = r
            .repository_id
            .as_deref()
            .ok_or_else(|| Error::new("invalid_request", "repository_id required"))?;
        aq_git_protocol::validate_id(id).map_err(|e| Error::new(e.code, e.message))?;
        let op = r
            .operation_id
            .as_deref()
            .ok_or_else(|| Error::new("invalid_request", "operation_id required"))?;
        let transition = format!("repositories/{id}/binding-transitions/{op}.json");
        if let Some(intent) = self.root.read_json::<Value>(&transition)? {
            return self.finish_binding(&transition, intent);
        }
        let old = self.checked_binding(r)?;
        let p: Update = serde_json::from_value(r.params.clone())?;
        let new = p.binding;
        if p.reason.trim().is_empty() {
            return Err(Error::new(
                "invalid_request",
                "Binding transition reason required",
            ));
        }
        if new.repository_id != old.repository_id
            || new.mode != old.mode
            || new.identity != old.identity
            || new.object_format != old.object_format
        {
            return Err(Error::new(
                "binding_conflict",
                "Identity, mode and object format cannot change",
            ));
        }
        if old.mode == "central"
            && new.binding_generation
                != old
                    .binding_generation
                    .checked_add(1)
                    .ok_or_else(|| Error::new("binding_conflict", "Generation exhausted"))?
            || old.mode == "worker" && new.binding_generation <= old.binding_generation
        {
            return Err(Error::new(
                "binding_conflict",
                "Replacement generation must advance according to mode",
            ));
        }
        Self::validate_profiles_and_remote(&new)?;
        for name in new.allowed_refs.iter().chain(new.allowed_targets.iter()) {
            aq_git_protocol::validate_ref(name).map_err(|e| Error::new(e.code, e.message))?;
        }
        if new
            .allowed_targets
            .iter()
            .any(|n| !n.starts_with("refs/heads/"))
        {
            return Err(Error::new(
                "invalid_request",
                "Publication targets must be branches",
            ));
        }
        if new.mode == "worker" && (new.remote_url.is_some() || new.credential_profile.is_some()) {
            return Err(Error::new(
                "invalid_request",
                "Worker bindings cannot contain remotes or credentials",
            ));
        }
        if let Some(url) = &new.remote_url
            && (url.contains(['\n', '\0'])
                || !(url.starts_with("https://")
                    || url.starts_with("ssh://")
                    || new.allow_file_transport
                        && (url.starts_with('/') || url.starts_with("file://"))))
        {
            return Err(Error::new(
                "unsupported_feature",
                "Remote protocol is not enabled",
            ));
        }
        let mut blockers = Vec::new();
        for relative in self.json_files("retention")? {
            let v: Value = self
                .root
                .read_json(&relative)?
                .ok_or_else(|| Error::new("state_corrupt", "Retention record disappeared"))?;
            if v["repository_id"] == id && v["state"] != "released" {
                blockers.push(json!({"kind":"retention","id":v["id"]}));
            }
        }
        for relative in self.json_files(&format!("repositories/{id}/workspaces"))? {
            let v: Value = self
                .root
                .read_json(&relative)?
                .ok_or_else(|| Error::new("state_corrupt", "Workspace record disappeared"))?;
            if v["lifecycle"] != "retired" {
                blockers.push(json!({"kind":"workspace","id":v["workspace_id"]}));
            }
        }
        for relative in self.json_files("operations")? {
            let v: Value = self
                .root
                .read_json(&relative)?
                .ok_or_else(|| Error::new("state_corrupt", "Operation record disappeared"))?;
            if v["id"] != op && v["payload"]["repository_id"] == id && v["status"] == "pending" {
                blockers.push(json!({"kind":"operation","id":v["id"]}));
            }
        }
        if !blockers.is_empty() {
            return Err(Error::new(
                "binding_in_use",
                "Live resources or unresolved operations block binding changes",
            )
            .details(json!({"blockers":blockers})));
        }
        let intent = json!({"format_version":1,"operation_id":op,"old":old,"new":new,"reason":p.reason,"complete":false});
        self.root.write_json(&transition, &intent)?;
        self.finish_binding(&transition, intent)
    }
    fn finish_binding(&self, path: &str, mut intent: Value) -> Result<Value> {
        let old: Binding = serde_json::from_value(intent["old"].clone())?;
        let new: Binding = serde_json::from_value(intent["new"].clone())?;
        if intent["complete"] == true {
            return Ok(serde_json::to_value(new)?);
        }
        let current = self.binding(&old.repository_id)?;
        if serde_json::to_value(&current)? != serde_json::to_value(&old)?
            && serde_json::to_value(&current)? != serde_json::to_value(&new)?
        {
            return Err(Error::new(
                "recovery_blocked",
                "Binding transition generation changed unexpectedly",
            ));
        }
        if intent["complete"] != true {
            self.root.write_json(
                format!(
                    "repositories/{}/binding-history/{}.json",
                    old.repository_id, old.binding_generation
                ),
                &old,
            )?;
            self.root.write_json(
                format!("repositories/{}/binding.json", new.repository_id),
                &new,
            )?;
            self.bindings
                .lock()
                .unwrap_or_else(|e| e.into_inner())
                .insert(new.repository_id.clone(), new.clone());
            self.invalidate(&new.repository_id);
            intent["complete"] = json!(true);
            self.root.write_json(path, &intent)?;
        }
        Ok(serde_json::to_value(new)?)
    }
    pub(super) fn json_files(&self, relative: &str) -> Result<Vec<String>> {
        let path = self.root.path().join(relative);
        let mut result = Vec::new();
        let entries = match std::fs::read_dir(path) {
            Ok(e) => e,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(result),
            Err(e) => return Err(e.into()),
        };
        for entry in entries {
            let entry = entry?;
            if entry.path().extension().is_some_and(|e| e == "json") {
                let name = entry
                    .file_name()
                    .into_string()
                    .map_err(|_| Error::new("state_corrupt", "Invalid metadata filename"))?;
                result.push(format!("{relative}/{name}"));
            }
        }
        Ok(result)
    }
    pub fn invalidate_storage(&self) {
        self.clear_cache()
    }
    pub fn recover_bindings(&self) -> Result<()> {
        let repositories = self.root.path().join("repositories");
        let entries = match std::fs::read_dir(repositories) {
            Ok(e) => e,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(()),
            Err(e) => return Err(e.into()),
        };
        for entry in entries {
            let id = entry?
                .file_name()
                .into_string()
                .map_err(|_| Error::new("state_corrupt", "Invalid repository directory"))?;
            aq_git_protocol::validate_id(&id).map_err(|e| Error::new(e.code, e.message))?;
            for path in self.json_files(&format!("repositories/{id}/binding-transitions"))? {
                let intent: Value = self
                    .root
                    .read_json(&path)?
                    .ok_or_else(|| Error::new("state_corrupt", "Transition disappeared"))?;
                let result = if intent["complete"] != true {
                    self.finish_binding(&path, intent.clone())?
                } else {
                    intent["new"].clone()
                };
                if let Some(id) = intent["operation_id"].as_str()
                    && let Some(operation) = self.root.operation(id)?
                    && operation.status == crate::state::OperationStatus::Pending
                {
                    self.root
                        .complete_operation(id, operation.generation, result)?;
                }
            }
        }
        Ok(())
    }
}
