//! Bounded persistent object reader with exact framing and discard on failure.
use super::{GitRunner, environment};
use crate::{Error, Result};
use std::{
    collections::BTreeMap,
    io::{Read, Write},
    os::{fd::AsRawFd, unix::process::CommandExt},
    path::{Path, PathBuf},
    process::{Child, ChildStdin, ChildStdout, Command, Stdio},
    sync::{Mutex, atomic::Ordering},
    time::Instant,
};
#[derive(Default)]
pub struct ObjectReaders {
    readers: Mutex<BTreeMap<PathBuf, Reader>>,
    exchanges: std::sync::atomic::AtomicU64,
}
struct Reader {
    child: Child,
    input: ChildStdin,
    output: ChildStdout,
    runner: GitRunner,
}
impl Drop for Reader {
    fn drop(&mut self) {
        unsafe {
            libc::kill(-(self.child.id() as i32), libc::SIGKILL);
        }
        let _ = self.child.wait();
        self.runner.counters.release_child();
    }
}
impl Reader {
    fn spawn(runner: &GitRunner, path: &Path) -> Result<Self> {
        let c = &runner.counters;
        let mut n = c.active.load(Ordering::Relaxed);
        loop {
            if n >= runner.limits.max_children {
                return Err(Error::new("overloaded", "Git child limit reached"));
            }
            match c
                .active
                .compare_exchange_weak(n, n + 1, Ordering::AcqRel, Ordering::Relaxed)
            {
                Ok(_) => break,
                Err(v) => n = v,
            }
        }
        let mut cmd = Command::new(&runner.git);
        environment::configure(&mut cmd);
        cmd.args(["cat-file", "--batch-command"])
            .current_dir(path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .process_group(0);
        if let Err(error) = runner.configure_resource_limits(&mut cmd) {
            c.release_child();
            return Err(error);
        }
        let mut child = match cmd.spawn() {
            Ok(c) => c,
            Err(_) => {
                c.release_child();
                return Err(Error::new("git_spawn", "Cannot launch object reader"));
            }
        };
        c.spawns.fetch_add(1, Ordering::Relaxed);
        let input = child.stdin.take().unwrap();
        let output = child.stdout.take().unwrap();
        unsafe {
            let fd = output.as_raw_fd();
            let flags = libc::fcntl(fd, libc::F_GETFL);
            libc::fcntl(fd, libc::F_SETFL, flags | libc::O_NONBLOCK);
        }
        Ok(Self {
            child,
            input,
            output,
            runner: runner.clone(),
        })
    }
    fn read(&mut self, buf: &mut [u8], start: Instant) -> Result<()> {
        let mut offset = 0;
        while offset < buf.len() {
            if super::remaining_deadline().is_some_and(|d| d.is_zero()) {
                return Err(Error::new(
                    "deadline_exceeded",
                    "Object reader request deadline expired",
                ));
            }
            if start.elapsed() >= self.runner.limits.timeout {
                return Err(Error::new("git_timeout", "Object reader deadline expired"));
            }
            match self.output.read(&mut buf[offset..]) {
                Ok(0) => {
                    return Err(Error::new(
                        "git_failed",
                        "Object reader exited during frame",
                    ));
                }
                Ok(n) => offset += n,
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    let mut p = libc::pollfd {
                        fd: self.output.as_raw_fd(),
                        events: libc::POLLIN,
                        revents: 0,
                    };
                    unsafe {
                        libc::poll(&mut p, 1, 10);
                    }
                }
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => {}
                Err(e) => return Err(e.into()),
            }
        }
        Ok(())
    }
    fn object(&mut self, oid: &str, limit: usize) -> Result<(String, Vec<u8>)> {
        if super::remaining_deadline().is_some_and(|d| d.is_zero()) {
            return Err(Error::new(
                "deadline_exceeded",
                "Object reader request deadline expired",
            ));
        }
        let start = Instant::now();
        self.input
            .write_all(format!("contents {oid}\n").as_bytes())?;
        self.input.flush()?;
        let mut header = Vec::new();
        loop {
            let mut byte = [0];
            self.read(&mut byte, start)?;
            if byte[0] == b'\n' {
                break;
            }
            header.push(byte[0]);
            if header.len() > 256 {
                return Err(Error::new("git_failed", "Malformed object header"));
            }
        }
        let header = std::str::from_utf8(&header)
            .map_err(|_| Error::new("git_failed", "Malformed object header"))?;
        let fields = header.split(' ').collect::<Vec<_>>();
        if fields.len() == 2 && fields[1] == "missing" {
            return Err(Error::new(
                "object_unavailable",
                "Exact object unavailable; synchronize or import it",
            ));
        }
        if fields.len() != 3 || fields[0] != oid {
            return Err(Error::new("git_failed", "Mismatched object frame"));
        }
        let len: usize = fields[2]
            .parse()
            .map_err(|_| Error::new("git_failed", "Malformed object size"))?;
        if len > limit {
            return Err(Error::new(
                "limit_exceeded",
                "Object exceeds metadata budget",
            ));
        }
        let kind = fields[1].to_owned();
        let mut data = vec![0; len];
        self.read(&mut data, start)?;
        let mut delimiter = [0];
        self.read(&mut delimiter, start)?;
        if delimiter[0] != b'\n' {
            return Err(Error::new("git_failed", "Malformed object delimiter"));
        }
        self.runner
            .counters
            .bytes
            .fetch_add((len + header.len() + 2) as u64, Ordering::Relaxed);
        Ok((kind, data))
    }
}
impl ObjectReaders {
    pub fn exchanges(&self) -> u64 {
        self.exchanges.load(Ordering::Relaxed)
    }
    pub fn invalidate(&self, path: &Path) {
        self.readers
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .remove(path);
    }
    pub fn clear(&self) {
        self.readers
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .clear()
    }
    pub fn object(
        &self,
        runner: &GitRunner,
        path: &Path,
        oid: &str,
        limit: usize,
    ) -> Result<(String, Vec<u8>)> {
        if oid.len() != 40 || !oid.bytes().all(|b| b.is_ascii_hexdigit()) {
            return Err(Error::new(
                "invalid_request",
                "Object reader requires full hexadecimal ID",
            ));
        }
        let mut readers = super::lock_with_deadline(&self.readers)?;
        let persistent_limit = 2.min(runner.limits.max_children.saturating_sub(1));
        if persistent_limit == 0 {
            readers.clear();
            let mut reader = Reader::spawn(runner, path)?;
            self.exchanges.fetch_add(1, Ordering::Relaxed);
            let started = Instant::now();
            let result = reader.object(oid, limit);
            runner.counters.duration.fetch_add(
                started.elapsed().as_micros().min(u64::MAX as u128) as u64,
                Ordering::Relaxed,
            );
            if result.as_ref().is_err_and(|error| {
                ["git_timeout", "deadline_exceeded"].contains(&error.code.as_str())
            }) {
                runner.counters.timeouts.fetch_add(1, Ordering::Relaxed);
            }
            return result;
        }
        if !readers.contains_key(path) {
            if readers.len() >= persistent_limit
                && let Some(k) = readers.keys().next().cloned()
            {
                readers.remove(&k);
            }
            readers.insert(path.to_owned(), Reader::spawn(runner, path)?);
        }
        self.exchanges.fetch_add(1, Ordering::Relaxed);
        let started = Instant::now();
        let result = readers.get_mut(path).unwrap().object(oid, limit);
        runner.counters.duration.fetch_add(
            started.elapsed().as_micros().min(u64::MAX as u128) as u64,
            Ordering::Relaxed,
        );
        if result
            .as_ref()
            .is_err_and(|error| ["git_timeout", "deadline_exceeded"].contains(&error.code.as_str()))
        {
            runner.counters.timeouts.fetch_add(1, Ordering::Relaxed);
        }
        if result.is_err() {
            readers.remove(path);
        }
        result
    }
}
